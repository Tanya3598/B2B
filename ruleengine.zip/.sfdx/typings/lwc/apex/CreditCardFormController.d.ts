declare module "@salesforce/apex/CreditCardFormController.getComponentSetup" {
  export default function getComponentSetup(param: {cartId: any}): Promise<any>;
}
declare module "@salesforce/apex/CreditCardFormController.handlePostPayment" {
  export default function handlePostPayment(param: {token: any, cartId: any, orderId: any, addressId: any, expirationMonth: any, expirationYear: any, cardholderName: any}): Promise<any>;
}
