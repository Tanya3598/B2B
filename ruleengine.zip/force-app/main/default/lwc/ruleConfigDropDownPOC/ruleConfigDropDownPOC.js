//import { LightningElement } from 'lwc';

//export default class RuleConfigDropDownPOC extends LightningElement {}

import { LightningElement, track, api, wire } from "lwc";
//import getObjects from "@salesforce/apex/RuleConfiguratonController.getAllObjects";
import getSupportedObjects from '@salesforce/apex/RuleConfiguratonController.getSupportedObjects';
import getAllRules from "@salesforce/apex/RuleConfiguratonController.getAllRules";
//import getAllRulesFilter from "@salesforce/apex/RuleConfiguratonController.getAllRulesFilter";
import delSelectedRules from "@salesforce/apex/RuleConfiguratonController.deleteSelectedRules";
import { refreshApex } from "@salesforce/apex";
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

const actions = [
  { label: 'Edit', name: 'edit' },
  { label: 'View Related', name: 'view' },
];

const columns = [
  {
    label: "RuleName",
    fieldName: "EPAMRuleEngine__Rule_Name__c",
    type: "text",
    cellAttributes: {
      alignment: `left`,
      class: {
        fieldName: `format`
      },
    }
  },
  {
    label: 'Sequence',
    fieldName: 'EPAMRuleEngine__Sequence__c',
    type: 'number',
    sortable: true,
    fixedWidth: 110,
    hideDefaultActions: true,
    cellAttributes: {
      alignment: `left`,
      class: {
        fieldName: `format`
      }
    },
  },
  {
    type: 'action',
    typeAttributes: { rowActions: actions },
  },
];

export default class RuleConfigDropDownPOC extends LightningElement {
  @track accounts;
  @track error;
  @track objectNameList = [];
  @track rules = [];
  @track visibleRules;
  @track rulesBackup;
  @track rulesFilter = [];
  @track data;
  @track relatedRuleExceptions;
  @track relatedRuleCriterias;
  @track relatedRuleActions;
  @track dataAll; // All Data available for data table 
  @track activeSections = [];
  @track ruleId;
  @track ruleName;
  @track recordsCount = 0;
  @track isDeleteTrue = false;
  @track labelDelete = "Delete Selected Rule(s)";
  @track sortBy = 'EPAMRuleEngine__Sequence__c';
  @track sortDirection = 'desc';

  recordSize = 10;
  displayAllRules = false;
  displayRuleRelatedRecords = false;
  displayActionModal = false;
  displayBottomGrid = false;
  objectsAvailable = false;
  loading = true;
  isActive = false;
  filterValue = null;
  selectedRecords = [];
  ruleTypeValue = '';
  isActiveValue = '';
  executionTypeValue = '';
  rulesAvailable = true;
  isOnLoad = true;
  disableConnectedCallback = false;
  pageOptions = [10, 25, 50, 100];

  columns = columns;
  selectedAction;
  selectedActionRowId;
  selectedExpActionRowId;
  actionEdit;
  actionEditRecord;
  actionViewRecord
  actionCreateRecord;
  ruleRecordTypeId;
  objectSelected;
  selectedisActiveValue;
  selectedExecutionTypeValue;
  selectedRuleTypeValue;
  ruleReadOnlyFieldVal;
  highlightRow = false; //30/03/2022 Nidhi


  @api recordId;
  @api
  get filtersSelected() {
    if (typeof this.selectedisActiveValue !== "undefined" || typeof this.selectedExecutionTypeValue !== "undefined" || typeof this.selectedRuleTypeValue !== "undefined") {
      return false;
    } else {
      return true;
    }
  }

  get options() {
    return [
      { label: '--None--', value: '' },
      { label: 'Email Configuration', value: 'Email Configuration' },
      { label: 'Field Evaluation Configuration', value: 'Field Evaluation Configuration' },
    ];
  }

  get isActiveOptions() {
    return [
      { label: '--None--', value: '' },
      { label: 'Active', value: 'True' },
      { label: 'InActive', value: 'False' },
    ];
  }

  get executionTypeOptions() {
    return [
      { label: '--None--', value: '' },
      { label: 'Before', value: 'True' },
      { label: 'After', value: 'False' },
    ];
  }

  get getobjectSelected() {
    return this.objectSelected ? false : true;
  }

  get ruleModalTitle() {
    return this.selectedActionRowId ? 'Edit Rule' : 'New Rule';
  }

  get allObjects() {
    return this.objectNameList;
  }

  //For Fetching Objects
  @wire(getSupportedObjects)
  wiredObjectNames({ data, error }) {
    if (data) {
      let newData = data.map(item => {
        let obj = {};
        obj.label = item['LabelName'];
        obj.value = item['ApiName'];
        return obj;
      });
      this.objectNameList = [...newData];
      this.objectsAvailable = true;
    }
    else if (error) {
      console.error('wiredObjectNames ==> ' + JSON.stringify(error));
      this.error = error;
      this.objectsAvailable = true;
      this.objectNameList = undefined;

    }

  }

  //For Handling Object Selection
  handleSelection(event) {
    this.rules = undefined;
    this.visibleRules = false;
    this.rulesBackup = undefined;
    this.displayRuleRelatedRecords = false;
    this.isOnLoad = true;
    this.actionCreateRecord = undefined;
    this.actionEditRecord = undefined;
    this.rulesAvailable = false;
    this.selectedActionRowId = undefined;
    this.objectSelected = event.detail.payload.value;
    this.sortDirection = 'desc';
    this.activeSections = [];
    this.ruleReadOnlyFieldVal = { 'EPAMRuleEngine__Rule_Object__c': this.objectSelected };
    if (this.objectSelected) {
      this.diplayRulesOfSelectedObject(); // For getting rules of selected object.
    }
  }

  //For fetching rules
  diplayRulesOfSelectedObject() {
    getAllRules({ objectApi: this.objectSelected })
      .then((result) => {
        let dataFromBackend = result;
        this.rulesBackup = result;
        let filteredRecords = this.filterRecords(dataFromBackend); //For UI filtering
        let sortedRecords = this.sortData(this.sortBy, this.sortDirection, filteredRecords); //For U.I Sorting
        this.rules = sortedRecords;

        if (this.isOnLoad) {
          this.visibleRules = sortedRecords;
          this.isOnLoad = false;
        }
      })
      .catch((error) => {
        this.error = error.body.message;
        this.rules = undefined;
        this.visibleRules = undefined;
        this.rulesBackup = undefined;
      })
      .finally(() => {
        this.loading = false;
        this.rulesAvailable = true;
      });

  }

  //For Filtering Rules
  filterRules() {
    let filteredRecords = this.filterRecords(this.rulesBackup);
    let sortedRecords = this.sortData(this.sortBy, this.sortDirection, filteredRecords);
    this.rules = [...sortedRecords];
  }

  //Filtering Function
  filterRecords(records) {
    if (this.selectedisActiveValue || this.selectedExecutionTypeValue || this.selectedRuleTypeValue) {
      let filter = {
        EPAMRuleEngine__Active__c: [],
        EPAMRuleEngine__Is_Execution_Before__c: [],
        EPAMRuleEngine__Is_Execution_After__c: [],
        EPAMRuleEngine__Rule_Type__c: [],
      };
      if (this.selectedisActiveValue === 'True') {
        filter.EPAMRuleEngine__Active__c[0] = true;
      }
      else if (this.selectedisActiveValue === 'False') {
        filter.EPAMRuleEngine__Active__c[0] = false;
      }
      if (this.selectedExecutionTypeValue === 'True') {
        filter.EPAMRuleEngine__Is_Execution_Before__c[0] = true;
      }
      else if (this.selectedExecutionTypeValue === 'False') {
        filter.EPAMRuleEngine__Is_Execution_After__c[0] = true;
      }
      if (this.selectedRuleTypeValue === 'Email Configuration') {
        filter.EPAMRuleEngine__Rule_Type__c[0] = 'Email Configuration';
      }
      else if (this.selectedRuleTypeValue === 'Field Evaluation Configuration') {
        filter.EPAMRuleEngine__Rule_Type__c[0] = 'Field Evaluation Configuration';
      }

      const query = this.buildFilter(filter);
      const result = this.filterData(this.rulesBackup, query);
      this.activeSections = [];
      return JSON.parse(JSON.stringify(result));

    } else {
      //console.log('inside else block');
      this.activeSections = [];
      return records;
    }
  }

  //Server Side Filtering
  filterRecordsInServer() {
    //for filtering on server side
    /*
      getAllRulesFilter({ 
           objectApi: this.objectSelected, 
           isActive: this.selectedisActiveValue, 
           ruleType:this.selectedRuleTypeValue, 
           executionType: this.selectedExecutionTypeValue})
      .then((result) => {
        this.rules = result;
        console.log('rules',result);
      })
      .catch((error) => {
        this.error = error.body.message;
        this.rules = undefined;
      })
      .finally(() => {
        this.loading = false;
      });
    */
  }

  DragStart(event) {
    this.dragStart = event.target.title;
    event.target.classList.add("drag");
  }

  DragOver(event) {
    event.preventDefault();
    return false;
  }

  Drop(event) {
    event.stopPropagation();
    const DragValName = this.dragStart;
    const DropValName = event.target.title;
    if (DragValName === DropValName) {
      return false;
    }
    const index = DropValName;
    const currentIndex = DragValName;
    const newIndex = DropValName;
    Array.prototype.move = function (from, to) {
      this.splice(to, 0, this.splice(from, 1)[0]);
    };
    this.rules.move(currentIndex, newIndex);
  }

  //For builiding filter criteria
  buildFilter(filter) {
    let query = {};
    for (let keys in filter) {
      if (filter[keys].constructor === Array && filter[keys].length > 0) {
        query[keys] = filter[keys];
      }
    }
    return query;
  }

  //For filtering data
  filterData(data, query) {
    const filteredData = data.filter((item) => {
      for (let key in query) {
        if (item[key] === undefined || !query[key].includes(item[key])) {
          return false;
        }
      }
      return true;
    });
    return filteredData;
  }

  //For column sorting
  doColumnSorting(event) {
    let fieldName = event.detail.fieldName;
    let sortDirection = event.detail.sortDirection;
    this.sortBy = fieldName;
    this.sortDirection = sortDirection;
    //this.sortData(fieldName, sortDirection);
    this.rules = this.sortData(fieldName, sortDirection, this.rules);
  }

  //Function to sort records
  sortData(fieldName, sortDirection, records) {
    let parseData = JSON.parse(JSON.stringify(records));
    // Return the value stored in the field
    let keyValue = (a) => {
      return a[fieldName];
    };
    // cheking reverse direction
    //console.log('sortDirection==>',sortDirection);
    let isReverse = sortDirection === 'asc' ? 1 : -1;
    // sorting data
    parseData.sort((x, y) => {
      x = keyValue(x) ? keyValue(x) : ''; // handling null values
      y = keyValue(y) ? keyValue(y) : '';
      // sorting values based on direction
      return isReverse * ((x > y) - (y > x));
    });
    return parseData;
  }

  //Event handler for pagination
  updateHandler(event) {
    this.visibleRules = JSON.parse(JSON.stringify(event.detail.records));
  }

  //Capture the event fired from the paginator component
  handlePaginatorChange(event) {
    this.visibleRules = event.detail;
    this.rowNumberOffset = this.visibleRules[0].rowNumber - 1;
  }

  //For toggling modal
  toggleRoleModal(event) {
    this.actionEditRecord = undefined;
    this.actionCreateRecord = undefined;
    this.selectedActionRowId = null;
  }

  //For handling row action
  handleRowAction(event) {
    const actionName = event.detail.action.name;
    const row = event.detail.row;
    //alert('row--->'+row.EPAMRuleEngine__Rule_Name__c);  
    console.log('event-->'+JSON.stringify(event)); 
    //console.log('selectedRows'+event.getTarget());
    //console.log('event.detail-->'+JSON.stringify(event.detail));  
    this.selectedActionRowId = row.Id;
    this.ruleId = row.Id;
    this.ruleName=row.EPAMRuleEngine__Rule_Name__c;
    this.highlightRow = true;
   // console.log('highlightRow===>', this.highlightRow);
    console.log('ruleId===>', this.ruleId);
    console.log('ruleName===>',this.ruleName);
    //let data = this.visibleRules;

    /*data.forEach(dat => {
      //console.log('data-->' + JSON.stringify(dat));
      if(dat.Id==this.selectedActionRowId)
      {dat.EPAMRuleEngine__Rule_Name__c = 'Test';
      console.log('Name---'+dat.EPAMRuleEngine__Rule_Name__c);
    }
    });
    this.visibleRules = data;*/
    
    //event.target.classList.add('highlight');
    //this.template.querySelector('format').classList.add('highlight');
    // row.add('highlight');

    this.selectedAction = actionName;
    switch (actionName) {
      case "edit":
        this.actionEditRecord = actionName;
        this.actionViewRecord = undefined;
        this.actionCreateRecord = undefined;
        this.displayRuleRelatedRecords = false;
        break;
      case "view":
        this.actionViewRecord = actionName;
        this.actionEditRecord = undefined;
        this.actionCreateRecord = undefined;
        this.displayRuleRelatedRecords = true;
        break;

      default:
    }

  }

  //For closing modal popup
  handleModalClose() {
    this.selectedActionRowId = null;
    this.selectedAction = null;
  }

  //For handling AddRule Click
  handleCreateNewRule() {
    console.log('Add New Rule Clicked!!');
    this.selectedActionRowId = undefined;
    this.actionCreateRecord = "create";
    this.actionEditRecord = 'edit';
  }

  //For Handling Save
  handleSave() {
    this.handleModalClose();
  }

  //For Handling Success
  handleRuleCreateEditSuccess() {
    this.rulesAvailable = false;
    this.toggleRoleModal();
    this.dispatchEvent(
      new ShowToastEvent({
        title: "Success!!",
        message: "Rule saved successfully!!",
        variant: "success"
      })
    );

    //refresh list of rules
    this.diplayRulesOfSelectedObject();
  }

  // handleRuleEditSuccess(){
  //   this.dispatchEvent(
  //     new ShowToastEvent({
  //       title: "Success!!",
  //       message: "Rule updated!!",
  //       variant: "success"
  //     })
  //   );   

  //   //refresh list of rules
  //   this.diplayRulesOfSelectedObject();
  // }

  handleSectionToggle(event) {
    this.activeSections = event.detail.openSections;
  }

  handleActiveOptionsChange(event) {
    this.selectedisActiveValue = event.detail.value;
  }

  handleexecutionTypeOptionsChange(event) {
    this.selectedExecutionTypeValue = event.detail.value;
  }

  handleDeleteRules() {
    if (Array.isArray(this.selectedRecords) && this.selectedRecords.length) {
      this.labelDelete = "Processing....";
      this.isDeleteTrue = true;
      delSelectedRules({ lstRuleIds: this.selectedRecords })
        .then((result) => {
          this.labelDelete = "Delete Selected Rules";
          this.isDeleteTrue = false;

          this.dispatchEvent(
            new ShowToastEvent({
              title: "Success!!",
              message: this.recordsCount + " records deleted.",
              variant: "success"
            })
          );
          this.template.querySelector("lightning-datatable").selectedRows = [];

          this.recordsCount = 0;

          //refresh list of rules
          this.diplayRulesOfSelectedObject();

        })
        .catch((error) => {
          this.dispatchEvent(
            new ShowToastEvent({
              title: "Error while deleting rules.",
              message: error.message,
              variant: "error"
            })
          );
        });
    } else {
      this.dispatchEvent(
        new ShowToastEvent({
          title: "Warning!!",
          message: " Select atleast one rule.",
          variant: "warning"
        })
      );
    }
  }

  getSelectedRules(event) {
    const selectedRows = event.detail.selectedRows;
    this.recordsCount = event.detail.selectedRows.length;
    let ruleIds = new Set();
    for (let i = 0; i < selectedRows.length; i++) {
      ruleIds.add(selectedRows[i].Id);
    }
    // coverting to array
    this.selectedRecords = Array.from(ruleIds);

  }

  refreshData() {
    this.loading = true;
    refreshApex(this.rules).finally(() => {
      this.loading = false;
    });
  }

  handleCheckboxChange(event) {
    this.isActive = event.target.checked;
  }

  handleChange(event) {
    this.ruleTypeValue = event.detail.value;
  }

  handleRuleTypeChange(event) {
    this.selectedRuleTypeValue = event.detail.value;
  }

  addColor(event) {
    event.target.classList.add('highlight');
  }

}