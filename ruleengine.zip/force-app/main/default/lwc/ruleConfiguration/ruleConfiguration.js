import { LightningElement, wire , track} from 'lwc';
import getObjects from '@salesforce/apex/RuleConfiguratonController.getAllObjects';
import getAllRules from '@salesforce/apex/RuleConfiguratonController.getAllRules';
import RULE_OBJECT from '@salesforce/schema/Rule__c';
import RULE_OBJECT_FIELD from '@salesforce/schema/Rule__c.Rule_Object__c';
import ACTIVE_FIELD from '@salesforce/schema/Rule__c.Active__c';
import SEQUENCE_FIELD from '@salesforce/schema/Rule__c.Sequence__c';
import RULE_CONDITION_FIELD from '@salesforce/schema/Rule__c.Rule_Conditon__c';
import RULE_TYPE_FIELD from '@salesforce/schema/Rule__c.Rule_Type__c';
import IS_BEFORE_FIELD from '@salesforce/schema/Rule__c.Is_Execution_After__c';
import IS_AFTER_FIELD from '@salesforce/schema/Rule__c.Is_Execution_Before__c';
export default class RuleConfiguration extends LightningElement {
    objectSelected;
    objectNameList = [];
    displayAllRules = false;
    rules = [];
    modalPopUpToggleFlag = false;

   @track columns = [
        {label: 'Rule Sequence', fieldName: 'Sequence__c', type: 'number', sortable: true },
        {label: 'Active', fieldName: 'Active__c', type: 'checkbox', sortable: true},
        {label: 'Rule Conditon', fieldName: 'Rule_Conditon__c', type: 'text', sortable: true},
        {label: 'Rule Type', fieldName: 'Rule_Type__c', type: 'text', sortable: true},
        {label: 'Is Execution After', fieldName: 'Is_Execution_After__c', type: 'checkbox', sortable: true},
        {label: 'Is Execution Before', fieldName: 'Is_Execution_Before__c', type: 'checkbox', sortable: true},
        {label: 'Action',  type: 'button'}
    ];

    @wire(getObjects) wiredObjectNames({data,error}){
        if(data){
            for(let objectName in data)
                this.objectNameList = [...this.objectNameList ,{value: data[objectName] , label: objectName}]; 
        
            this.error = undefined;
        }
        else if(error){
            this.error = error;
            this.allObjects = undefined;
        }
    }

    get allObjects(){
        return this.objectNameList;
    }
   
    handleSelectObjectChange(event){
        this.objectSelected = event.detail.value; 
        this.displayAllRules = true;
        
        getAllRules({objectApi: this.objectSelected})
        .then(result=>{
            this.rules = result;
            console.log("RULES : " , this.rules);
        })
        .catch(error=>{
            console.log("error in fetching rules : " , error);
            this.rules = undefined;
        });
    }

    handleAddNewRule(){
        this.modalPopUpToggleFlag = true;
    }

    handleSkip(){
        this.modalPopUpToggleFlag = false;
    }

    handleCreateNewRule(){

    }
}