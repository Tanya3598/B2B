import { LightningElement,api,track } from 'lwc';
import getAllRules from "@salesforce/apex/SeqTabConfiguratonController.getAllRules";

export default class NewCompDragDropTableSeq extends LightningElement {
    @track dragStart;
    @track ElementList = [];
    @track objectSelected = 'Account';

    connectedCallback() {
        getAllRules({ objectApi: this.objectSelected })
        .then((result) => {
            for (let i = 0; i < result.length; i++) {
                this.ElementList.push(result[i]);
            }
        })
        .catch((error) => {
            console.log("###Error : " + error.body.message);
        });

        console.log("this.ElementList : " + JSON.stringify(this.ElementList));
    }

    Change(event){
        this.ElementList = event.detail.join(', ');
        console.log('Rows got changed');
    }

    DragStart(event) {
        console.log('event>>'+event.target);
        this.dragStart = event.target.title;
        event.target.classList.add("drag");
    }

    DragOver(event) {
        event.preventDefault();
        return false;
    }

    Drop(event) {
        event.stopPropagation();
        const DragValName = this.dragStart;
        const DropValName = event.target.title;
        if (DragValName === DropValName) {
            return false;
        }
        const index = DropValName;
        console.log('index>>'+index);
        const currentIndex = DragValName;
        console.log('currentIndex>>'+currentIndex);
        const newIndex = DropValName;
        console.log('newIndex>>'+newIndex);
        Array.prototype.move = function (from, to) {
            console.log('from>>'+from+JSON.stringify(from));
            console.log('to>>'+from+JSON.stringify(to));
            this.splice(to, 0, this.splice(from, 1)[0]);
        };
        this.ElementList.move(currentIndex, newIndex);
        console.log('type of this.ElementList currentIndex>>'+typeof(this.ElementList[currentIndex]));
        console.log('this.ElementList currentIndex>>'+JSON.stringify(this.ElementList[currentIndex]));
        console.log('this.ElementList newIndex>>'+JSON.stringify(this.ElementList[newIndex]));
        //onsole.log('Sequencing>>'+this.ElementList[currentIndex].EPAMRuleEngine__Sequence__c);
    }
}