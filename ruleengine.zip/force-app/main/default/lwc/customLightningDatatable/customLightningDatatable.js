import LightningDatatable from 'lightning/datatable';
import customRuleName from './customRuleName';

export default class CustomLightningDatatable extends LightningDatatable {


    static customTypes = {
        customName: {
            template: customRuleName,
            typeAttributes: ['recordId', 'customName']
        }
    }


}