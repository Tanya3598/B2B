import { LightningElement,api } from 'lwc';
const closeLabel = 'Close';
export default class Modal extends LightningElement {
    /**
     * Modal title
     * @type {string}
     * @private
     */
     _title;
     /**
      * Header visibility
      * @type {boolean}
      * @private
      */
     _showHeader = true;
     /**
      * Subtitle visibility
      * @type {boolean}
      * @private
      */
     _showSubTitle = false;
     /**
      * Footer visibility
      * @type {boolean}
      * @private
      */
     _showFooter = true;
     /**
      * Close button visibility
      * @type {boolean}
      * @private
      */
     _showClose = true;
     /**
      * Modal size
      * @type {string}
      * @private
      */
     _size;
     /**
      * Modal classes
      * @type {string}
      * @private
      */
     _modalClass;
 
     /**
      * Modal's header classes
      * @type {string}
      * @private
      */
     _headerClass;
 
     /**
      * Modal's footer classes
      * @type {string}
      * @private
      */
     _footerClass;
 
     /**
      * Close label
      * @type {string}
      */
     closeLabel = closeLabel;
 
     @api
     closeIconSize = "small";
     @api
     tabIdx = -1;
 
     /**
      * Set modal title
      * @param value {string} A string modal title
      * @public
      */
     @api set title(value) {
         this._title = value;
     };
 
     /**
      * Set modal header visibility
      * @param value {boolean}
      * @public
      */
     @api set showHeader(value) {
         this._showHeader = value;
     };
 
     /**
      * Set modal subtitle visibility
      * @param value {boolean}
      * @public
      */
     @api set showSubTitle(value) {
         this._showSubTitle = value;
     };
 
     /**
      * Set modal footer visibility
      * @param value {boolean}
      * @public
      */
     @api set showFooter(value) {
         this._showFooter = value;
     };
 
     /**
      * Set modal close button visibility
      * @param value {boolean}
      * @public
      */
     @api set showClose(value) {
         this._showClose = value;
     };
 
     /**
      * Set modal size
      * @param value {string} Available values: small, medium, large
      * @public
      */
     @api set size(value) {
         this._size = value;
     };
 
     /**
      * Set modal class
      * @param value {string} A string of modal classes
      * @public
      */
     @api set modalClass(value) {
         this._modalClass = value;
     };
 
     /**
      * Set modal class
      * @param value {string} A string of header classes
      * @public
      */
     @api set headerClass(value) {
         this._headerClass = value;
     };
 
     /**
      * Set modal class
      * @param value {string} A string of footer classes
      * @public
      */
     @api set footerClass(value) {
         this._footerClass = value;
     };
 
     /**
      * Get modal title
      * @returns {string}
      */
     get title() {
         return this._title;
     };
 
     /**
      * Get header visibility
      * @returns {boolean}
      */
     get showHeader() {
         return this._showHeader;
     };
 
     /**
      * Get subtitle visibility
      * @returns {boolean}
      */
     get showSubTitle() {
         return this._showSubTitle;
     };
 
     /**
      * Get footer visibility
      * @returns {boolean}
      */
     get showFooter() {
         return this._showFooter;
     };
 
     /**
      * Get close button visibility
      * @returns {boolean}
      */
     get showClose() {
         return this._showClose;
     };
 
     /**
      * Get modal size
      * @returns {string}
      */
     get size() {
         return `slds-modal slds-fade-in-open slds-modal_${this._size ? this._size : 'small'}`;
     };
 
     /**
      * Get modal classes
      * @returns {string}
      */
     get modalClass() {
         return `slds-modal__container ${this._modalClass}`;
     };
 
     /**
      * Get modal header classes
      * @returns {string}
      */
     get headerClass() {
         return this._headerClass == null? 'slds-modal__header': 'slds-modal__header ' +this._headerClass;
     };
 
     /**
      * Get modal footer classes
      * @returns {string}
      */
     get footerClass() {
         return this._footerClass == null? 'slds-modal__footer': 'slds-modal__footer ' +this._footerClass;
     };
 
     /**
      * Modal close button action
      * @see close
      */
     onClose() {
         const closeEvent = new CustomEvent('close', {
             detail: null,
         });
         this.dispatchEvent(closeEvent);
     };
}