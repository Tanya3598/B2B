import { LightningElement,api } from 'lwc';
const EDITABLE_FIELDS=['EPAMRuleEngine__Rule_Name__c','EPAMRuleEngine__Rule_Type__c','EPAMRuleEngine__Rule_Conditon__c',
            'EPAMRuleEngine__Is_Execution_After__c','EPAMRuleEngine__Is_Execution_Before__c',
            'EPAMRuleEngine__Active__c','EPAMRuleEngine__Sequence__c'];
const READ_ONLY_FIELDS=['EPAMRuleEngine__Rule_Object__c'];
export default class RuleForm extends LightningElement {
    @api recordId;
    @api objectDeveloperName='EPAMRuleEngine__Rule__c'  ;
    @api editableFields = EDITABLE_FIELDS;
    @api readOnlyFields = READ_ONLY_FIELDS;

    readOnlyFieldsWrap; 
    showSpinner=true;
    _readOnlyFieldsVal={};

    handleLoad(event){
        this.showSpinner = false;
    }
    
    handleError(event){
        this.showSpinner = false;
        console.error(event);
    }
    @api
    get readOnlyFieldsVal(){
        return this._readOnlyFieldsVal;
    }
    set readOnlyFieldsVal(value){
        // console.log('@@recordId==>',this.recordId);
        // console.log('@@objectDeveloperName==>',this.objectDeveloperName);
        // console.log('@@editableFields==>',JSON.parse(JSON.stringify(this.editableFields)));
        // console.log('@@readOnlyFields==>',JSON.parse(JSON.stringify(this.readOnlyFields)));
        this._readOnlyFieldsVal = value;
        this.readOnlyFieldsWrap= this.readOnlyFields.map((fieldName)=>{
                     return {'fieldName':fieldName,'fieldValue':value[fieldName]};
                });
    }
    handleSuccess(event){
        //console.log('onsuccess==>',event);
        const updatedRecord = event.detail.id;
        const successEvt = new CustomEvent('successevt', {
            detail: updatedRecord 
        });
        this.dispatchEvent(successEvt);
        this.showSpinner = false;
    }
    handleSave(event){
        event.preventDefault();       // stop the form from submitting
        this.showSpinner = true;
        const fields = event.detail.fields;
        for(let key in this._readOnlyFieldsVal){
            if(this._readOnlyFieldsVal[key]){
                fields[key]=this._readOnlyFieldsVal[key];
            }
        } 
        this.template.querySelector('lightning-record-edit-form').submit(fields);
    }
    handleCancel(){
        const successEvt = new CustomEvent('close', {
            detail: null,
        });
        this.dispatchEvent(successEvt);
    }

}