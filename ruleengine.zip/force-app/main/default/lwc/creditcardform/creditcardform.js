import { LightningElement , api} from 'lwc';
import getComponentSetup from '@salesforce/apex/CreditCardFormController.getComponentSetup';
import handlePostPayment from '@salesforce/apex/CreditCardFormController.handlePostPayment';


export default class CreditCardFormLwc extends LightningElement {


@api microform = null;
@api token = 'a101';
@api orderId = '8012C000001sXgZQAU'; 
@api cartId = '0a62C000000CabvQAC';
@api cardholderName;
@api selectedCardType;
@api selectedMonth;
@api selectedYear;
@api selectedAddress = '9948 Mayflower,Street Atlanta, GA 30303,USA';
@api selectedPaymentMethod = "CardPayment"; 
@api cardTypes = [];
@api addresses = []; 
@api months = []; 
@api years = [];
@api disableButton; 
@api hideCreditCardSection;
@api navigateFlow;


connectedCallback(){
    console.log('doInit called');
    this.populatePicklists();
    this.makeApexCallout();
}

populatePicklists(){
    console.log('populatePicklists called');
    let months = [];
    let years = [];
    let currYear = new Date().getFullYear();
    
    for(let i = 0; i < 20; i++) {
        if(i < 12) {
            months.push({'label' : String(i + 1), 'value' : String(i + 1)});
        }
        years.push({'label' : String(currYear + i), 'value' : String(currYear + i)});
    }
    
    this.months = months;
    this.years = years;
    
}

makeApexCallout(){
    console.log('makeApexCallout called');

    getComponentSetup({ cartId: this.cartId }) 
            .then((result) => {               
                this.error = undefined;
            })
            .catch((error) => {
                this.error = error;               
            });    
}

makeApexCallout_Callback(){
    return (function(a){
        var state = a.getState(); 
        console.log('makeApexCallout_Callback called : ' + state);
        if (state === "SUCCESS") {  
            this.handleResponse(a.getReturnValue());
        } else {
            //TODO - add error handling to display messages/etc.
            console.debug('Error occurred');
        }
    });
}

handleCardTypeChange(event){
    console.log('Card Type Dropdown Clicked');
    this.selectedCardType = event.target.value;
}

handleMonthChange(event){
    console.log('Handle Month Change Clicked');
    this.selectedMonth = event.target.value;
}

handleYearChange(event){
    console.log('Handle Year Change Clicked');
    this.selectedYear = event.target.value;
}

handleAddressChange(event){
    console.log('Handle Address Change Clicked');
    this.selectedAddress = event.target.value;
}

handleResponse(response){
    console.log('handleResponse called');
    this.handleCardTypes(response.cardTypes);
    this.handleAddresses(response.addresses);
    this.setupForm(response.keyId);
}

handleCardTypes(){
    let cardTypes = [];        
    //TODO - CardType returned from Apex not returning detailed information - populate with dummy value for now
    cardTypes.push({"label" : "Visa", "value" : "Visa"});
    this.cardTypes = cardTypes;
   
}

handleAddresses(vals){
    let addresses = [];

    for(let i = 0; i < vals.length; i++) {
        let currAddress = vals[i]; 
        let label = currAddress.Address.street + ", " + currAddress.Address.city + ", " + currAddress.Address.state + " " + currAddress.Address.postalCode + " " + currAddress.Address.country;
        
        addresses.push({'label' : label, 'value' : currAddress.Id})
    }

    this.addresses = addresses;
    
}

setupForm(captureContext){
    //Sample code from Cybersource: https://developer.cybersource.com/api/developer-guides/dita-flex/SAFlexibleToken/FlexMicroform/get-started/flex-getting-started-examples.html
    var flex = new Flex(captureContext);  
    var microform = flex.microform({'input': {'line-height': '1.875rem'} });
    this.microform = microform;
       
    var number = microform.createField('number', { placeholder: 'Enter a card number...' });
    var securityCode = microform.createField('securityCode', { placeholder: '•••' });
    number.load('#number-container');
    securityCode.load('#securityCode-container');
}

handlePayClick(){
     //Sample code from Cybersource: https://developer.cybersource.com/api/developer-guides/dita-flex/SAFlexibleToken/FlexMicroform/get-started/flex-getting-started-examples.html
     console.log('Handle Pay Click : ');   
     let monthVal = parseInt(this.selectedMonth);
     
     //TODO - Need to refactor for long-term - Cybersource requires months < 10 to come through as double-digit
     if(monthVal < 10) {
        this.selectedMonth = "0" + String(monthVal);
     }
     
     var options = {    
         expirationMonth: this.selectedMonth,  
         expirationYear: this.selectedYear
     };     

     var self = this;
     this.component = component;
     
     this.microform.createToken(options, function (err, token) {
         if (err) {
             //TODO - add error handling to display messages/etc.
             console.error(err);
             errorsOutput.textContent = err.message;
         } else {    
             self.submitPayment(self.component, token);
         }
     });
}

submitPayment(){
     //TODO - add spinner to prevent form interaction while handling payment
     console.log('Submit Payment Called');
     handlePostPayment({ 
                        token:  this.token, 
                        cartId : this.cartId, 
                        orderId : this.orderId,  
                        addressId : this.selectedAddress,  
                        expirationMonth : this.selectedMonth, 
                        expirationYear : this.selectedYear, 
                        cardholderName : this.cardholderName}) 
     .then((result) => {   
        this.submitPayment_Callback();            
        this.error = undefined;
     })
     .catch((error) => {
         this.error = error;               
     });
    
}

submitPayment_Callback(){
    return (function(a){
        var state = a.getState(); 

        if (state === "SUCCESS") { 
            //Likely not needed but added in the event that this value was accidentally overridden (it is needed for the Flow)
            this.selectedPaymentMethod = CardPayment;
            
            //Move the flow forward if the response is successfully
            var navigate = this.navigateFlow;
            navigate("NEXT");
        } else {
            //TODO - add error handling to display messages/etc.
            console.debug('Error occurred');
        }
    });
}

}