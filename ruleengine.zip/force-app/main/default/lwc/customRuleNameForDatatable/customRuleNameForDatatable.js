import { LightningElement, api } from 'lwc';

export default class CustomRuleNameForDatatable extends LightningElement {


    @api recordId;
    @api customName;
 
    fireCustomNameClick() {
        let newCustomName = this.customName + 1;
        const event = new CustomEvent('customname', {
            composed: true,
            bubbles: true,
            cancelable: true,
            detail: {
                recordId: this.recordId,
                newCustomName: newCustomName
            },
        });
        this.dispatchEvent(event);
    }

}