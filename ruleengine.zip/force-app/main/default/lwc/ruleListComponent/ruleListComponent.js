import { LightningElement } from 'lwc';

export default class RuleListComponent extends LightningElement {}