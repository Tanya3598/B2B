import { LightningElement, wire,api,track} from 'lwc';
import { refreshApex } from '@salesforce/apex';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getRuleData from '@salesforce/apex/RuleConfiguratonController.getRuleData';
import createOrUpdateRuleRecord from '@salesforce/apex/RuleConfiguratonController.createOrUpdateRuleRecord';

const RULE_CONDITION_PICKLIST_VALUES = [
{label: 'All Conditions Are Met', value: 'All Conditions Are Met'},
{label: 'Any Condition Is Met', value: 'Any Condition Is Met'},
{label: 'Custom Logic Is Met', value: 'Custom Logic Is Met'},
{label: '--None--', value: ''},
];
const RULE_TYPE_PICKLIST_VALUES = [
    {label: 'Email Configuration', value: 'Email Configuration'},
    {label: 'Field Evaluation Configuration', value: 'Field Evaluation Configuration'},
    {label: '--None--', value: ''},
    ];

export default class RuleConfigForm extends LightningElement {
@api recordId; 
name;
ruleSequence;
active;
ruleConditon;
ruleType;
isExecutionAfter;
isExecutionBefore;
record;
error;
ruleConditionPicklistValues=RULE_CONDITION_PICKLIST_VALUES;
ruleTypePicklistValues=RULE_TYPE_PICKLIST_VALUES;
ruleObject;
@track wiredRecord= [];

@wire(getRuleData, {recordId: '$recordId'})
getWiredRecord(result) {
    this.wiredRecord = result;
    const { data, error } = result;
    if (data) {
        this.record = data;
        this.name=data.name;
        this.ruleSequence = data.Sequence__c;
        this.active = data.Active__c;
        this.ruleConditon = data.Rule_Conditon__c;
        this.ruleType = data.Rule_Type__c;
        this.isExecutionAfter = data.Is_Execution_After__c;
        this.isExecutionBefore = data.Is_Execution_Before__c;
        this.ruleObject=data.Rule_Object__c;
    } else if (error) {
        this.error = error;
        console.log(error);
    }
    this.loading = false;
}
connectedCallback() {
    this.refreshCache();
}

handleSave() {    
    let inputCmps = this.template.querySelectorAll('.input');
    console.log(inputCmps);
    let allValid = [...inputCmps].reduce((validSoFar, cmp) => {
        cmp.reportValidity();
        return validSoFar && cmp.checkValidity();
    }, true);
    if (allValid) {                 
        this.loading = true;
        console.log('active::'+this.active);
        createOrUpdateRuleRecord({ 
            ruleRecordId: this.recordId,             
            active: this.active, 
            ruleSequence:this.ruleSequence,
            ruleConditon: this.ruleConditon, 
            ruleType: this.ruleType,            
            isExecutionAfter: this.isExecutionAfter,
            isExecutionBefore: this.isExecutionBefore,
            ruleObject:this.ruleObject
        })
            .then(() => {               
                const toastEvent = new ShowToastEvent({
                    title: 'Success',
                    message: 'The rule has been successfully created or updated.',
                    variant: 'success'
                });
                this.dispatchEvent(toastEvent);
                this.dispatchEvent(new CustomEvent('save'));                
            })
            .catch(error => {
                console.log('Error::'+error.body.message[0].message);
                const toastEvent = new ShowToastEvent({
                    title: 'Something went wrong',
                    message: error.body.message[0].message,
                    variant: 'error'
                });
                this.dispatchEvent(toastEvent);
            })
            .finally(() => {
                this.loading = false;
            });
    }
}
async refreshCache() {   
    if (this.recordId.substring(0,3) === 'a00') {         
        this.loading = true;
        if (this.dataInitialized) {
            await refreshApex(this.wiredRecord);                
            this.loading = false;
        }
        else {
            setTimeout(() => {
                this.refreshCache();
            }, 1000);
        }
    }
}
get dataInitialized() {      
    return ((this.recordId && this.record) || !this.recordId);
}
handleCancel() {
    this.dispatchEvent(new CustomEvent('cancel'));
}
handleRuleObjectChange(event) {
    this.ruleObject = event.target.value;
}

handleRuleTypeChange(event) {
    this.ruleType = event.target.value;
}

handleRuleConditonChange(event) {
    this.ruleConditon = event.target.value;
}

handleIsExecutionAfterChange(event) {
    this.isExecutionAfter =  event.target.checked;
}
handleIsExecutionBeforeChange(event) {
    this.isExecutionBefore =  event.target.checked;
}
handleRuleSequenceChange(event){    
    this.ruleSequence=event.target.value;
}
handleActiveChange(event){   
    this.active=event.target.checked;
}
get requiredFieldsPresent() {
    return this.ruleConditon && this.ruleType && this.ruleObject;
}
handleRuleConditionChange(event) {
    this.ruleConditon = event.target.value;
}
handleRuleTypeChange(event){
    this.ruleType=event.target.value;
}
}