import { LightningElement, api, track } from 'lwc';

export default class Pagination extends LightningElement {
    @track currentPage =1;
    totalRecords;
    totalPage = 0;
    @track startingRecord = 1; 
    @track endingRecord = 0;
    visibleRecords;
    @track totalRecountCount = 0;

    @api recordSize = 5;
    @api
    get records(){
        return this.visibleRecords
    }
    set records(data){
        let newRecords =[];
        let deserlizedData = JSON.parse(JSON.stringify(data));
        if(deserlizedData){ 
            this.currentPage = 1;

            this.totalRecountCount = deserlizedData.length;
            this.totalRecords = deserlizedData;
            this.recordSize = Number(this.recordSize)
            this.totalPage = Math.ceil(deserlizedData.length/this.recordSize)
            
            this.endingRecord = (this.recordSize > this.totalRecountCount)
            ? this.totalRecountCount : this.recordSize;

            this.updateRecords()
        }
    }

    get disablePrevious(){ 
        return this.currentPage<=1
    }
    get disableNext(){ 
        return this.currentPage>=this.totalPage
    }

    previousHandler(){ 
        if(this.currentPage>1){
            this.currentPage = this.currentPage-1
            this.updateRecords()
            this.displayRecord(this.currentPage)
            
        }
    }

    nextHandler(){
        if(this.currentPage < this.totalPage){
            this.currentPage = this.currentPage+1
            this.updateRecords()
            this.displayRecord(this.currentPage)
        }
    }

    updateRecords(){ 
        
        const start = (this.currentPage-1)*this.recordSize
        const end = this.recordSize*this.currentPage
        this.visibleRecords = this.totalRecords.slice(start, end)
        this.dispatchEvent(new CustomEvent('update',{ 
            detail:{ 
                records:this.visibleRecords
            }
        })) 
        

    }

    displayRecord(page){

        /*let's say for 2nd page, it will be => "Displaying 6 to 10 of 23 records. Page 2 of 5"
        page = 2; pageSize = 5; startingRecord = 5, endingRecord = 10
        so, slice(5,10) will give 5th to 9th records.
        */
        this.startingRecord = ((page -1) * this.recordSize) ;
        this.endingRecord = (this.recordSize * page);

        this.endingRecord = (this.endingRecord > this.totalRecountCount) 
                            ? this.totalRecountCount : this.endingRecord; 

        this.data = this.totalRecords.slice(this.startingRecord, this.endingRecord);

        //increment by 1 to display the startingRecord count, 
        //so for 2nd page, it will show "Displaying 6 to 10 of 23 records. Page 2 of 5"
        this.startingRecord = this.startingRecord + 1;
    }    
}
