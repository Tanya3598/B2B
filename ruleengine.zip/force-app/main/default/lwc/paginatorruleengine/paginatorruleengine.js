import { LightningElement, api, track, wire, } from 'lwc';
import { subscribe, unsubscribe, MessageContext } from 'lightning/messageService';
import PaginatorDetails from '@salesforce/messageChannel/PaginatorDetails__c';

const DELAY = 300;
const recordsPerPage = [5,10,25,50,100];
const pageNumber = 1;
const showIt = 'visibility:visible';
const hideIt = 'visibility:hidden'; //visibility keeps the component space, but display:none doesn't
export default class Pagination extends LightningElement {
    @track currentPage =1;
    totalRecordsBackup;
    totalRecords;
    totalPage = 0;
    @track startingRecord = 1; 
    @track endingRecord = 0;
    visibleRecords;
    @track totalRecountCount = 0;
    @api pageSizeOptions = recordsPerPage; //Page size options; valid values are array of integers
    //Sizes for previous button
    // @recordsPerPageapi pageSizeOptions = [5,10,25,50,100];
    // @api previousSize = 12;
    // @api previousSmallSize = 8;
    // @api previousMediumSize = 3;
    // @api previousLargeSize = 4

    //Sizes for Page Options
    @api optionsSize = 12;
    @api optionsSmallSize = 8;
    @api optionsMediumSize = 5;
    @api optionsLargeSize = 4;

    //Sizes for Next Button
    @api nextSize = 12;
    @api nextSmallSize = 8;
    @api nextMediumSize = 3;
    @api nextLargeSize = 4;

    @track controlPagination = showIt;
    @track controlPrevious = hideIt; //Controls the visibility of Previous page button
    @track controlNext = showIt; //Controls the visibility of Next page button

    @api recordSize = 5;
    @api
    get records(){
        return this.visibleRecords
    }
    set records(data){
        let newRecords =[];
        let deserlizedData = JSON.parse(JSON.stringify(data));
        if(deserlizedData){ 
            this.currentPage = 1;
            //console.log('records inside pagination init',deserlizedData);
         
            // deserlizedData.forEach((item,index) => {
            //     let opp ={};
            //     opp.RowNumber = index + 1;
            //     opp = Object.assign(opp, item);
            //     newRecords.push(opp);
            // });
            
            //this.totalRecords = newRecords;
            //offset = (this.currentPage-1)*this.recordSize;
            this.totalRecountCount = deserlizedData.length;
            this.totalRecords = deserlizedData;
            this.recordSize = Number(this.recordSize)
            this.totalPage = Math.ceil(deserlizedData.length/this.recordSize)
            
            this.endingRecord = (this.recordSize > this.totalRecountCount)
            ? this.totalRecountCount : this.recordSize;
            //this.recordStart = offset + 1;
            //this.recordEnd = totalRecords >= recordEnd ? recordEnd : totalRecords;
            //const start = (this.currentPage-1)*this.recordSize
            //const end = this.recordSize*this.currentPage
            console.log(deserlizedData)

            this.updateRecords()
        }
    }

    handleRecordsPerPage(value){
        this.pageSize = value;
        this.recordSize = this.pageSize;
        this.updateRecords();
        this.displayRecord(this.currentPage);
    
    }
    

    get disablePrevious(){ 
        return this.currentPage<=1
    }
    get disableNext(){ 
        return this.currentPage>=this.totalPage
    }

    previousHandler(){ 
        if(this.currentPage>1){
            this.currentPage = this.currentPage-1
            this.updateRecords()
            this.displayRecord(this.currentPage)
            
        }
    }

    nextHandler(){
        if(this.currentPage < this.totalPage){
            this.currentPage = this.currentPage+1
            this.updateRecords()
            this.displayRecord(this.currentPage)
        }
    }

    updateRecords(){ 
        
        const start = (this.currentPage-1)*this.recordSize
        const end = this.recordSize*this.currentPage
        this.visibleRecords = this.totalRecords.slice(start, end)
        this.dispatchEvent(new CustomEvent('update',{ 
            detail:{ 
                records:this.visibleRecords
            }
        })) 
        

    }

    // handleRecordsPerPage(event){
    //     this.recordSize = event.target.value;
    //     this.totalPage = Math.ceil(this.totalRecords.length/this.recordSize)
    //     this.currentPage = 1;
    //     this.updateRecords();
    // }

    displayRecord(page){

        /*let's say for 2nd page, it will be => "Displaying 6 to 10 of 23 records. Page 2 of 5"
        page = 2; pageSize = 5; startingRecord = 5, endingRecord = 10
        so, slice(5,10) will give 5th to 9th records.
        */
        this.startingRecord = ((page -1) * this.recordSize) ;
        this.endingRecord = (this.recordSize * page);

        this.endingRecord = (this.endingRecord > this.totalRecountCount) 
                            ? this.totalRecountCount : this.endingRecord; 

        this.data = this.totalRecords.slice(this.startingRecord, this.endingRecord);
        this.totalPage = Math.ceil(this.totalRecords.length/this.recordSize);

        //increment by 1 to display the startingRecord count, 
        //so for 2nd page, it will show "Displaying 6 to 10 of 23 records. Page 2 of 5"
        this.startingRecord = this.startingRecord + 1;
    }   
    
    subscription = null;
  @wire(MessageContext)
  messageContext;
  connectedCallback() {
    this.subscription = subscribe(
      this.messageContext,
      PaginatorDetails,
      (paginatorDetailsMessage) => {
        console.log(paginatorDetailsMessage.data.toString());
        console.log('Data Recieved')
      }
    );    

  }

  disconnectedCallback() {
    unsubscribe(this.subscription);
    this.subscription = null;
  }
}