import { LightningElement, api, wire, track } from 'lwc';
import getAllFields from '@salesforce/apex/RuleConfiguratonController.getAllFieldsForObject';

export default class RuleCriteriaFormulaBuilder extends LightningElement {
    @api objectName = 'Account';
    lstSelected = [];
    @track lstOptions = [];
    @track evaluationCriteria;

    //@wire(getAllFields, { objectApiName : "$objectName"})
    @wire(getAllFields, { objectApiName : "Account"})
    wiredGetAllFields({error, data}) {
        console.log('data>>'+data+JSON.stringify(data));
        if(data) {
        // if(data && data.data && data.data.values) {
            this.lstOptions = data;
            // data.data.values.forEach( objPicklist => {
            //     this.lstOptions.push({
            //         label: objPicklist.label,
            //         value: objPicklist.value
            //     });
            // });
            // data.forEach(objPicklist => {
            //     this.lstOptions.push({
            //         label: objPicklist.label,
            //         value: objPicklist.value
            //     });
            // });
        } else if(error) {
            console.log('error>>>'+error);
        }
    }

    connectedCallback() {
        
    }

    handleChange(event) {
        this.lstSelected = event.detail.value;
    }
}