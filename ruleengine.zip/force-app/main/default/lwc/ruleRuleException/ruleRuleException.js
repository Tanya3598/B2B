import { LightningElement ,api,track,wire} from 'lwc';
import { refreshApex } from "@salesforce/apex";
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getRuleExceptions from "@salesforce/apex/RuleConfiguratonController.getRuleExceptions";

const exceptionColumns=[
{label: "Rule Exception Name", fieldName: "Name", type: "text", sortable: true },  
{label: "Eligibility Criteria", fieldName: "Eligibility_Criteria__c", type: "text", sortable: true},
{label: "Exception Message",fieldName: "Exception_Message__c", type: "text", sortable: true },
{
    type: "button",
    label: "Action",
    typeAttributes: {
    label: "View/Edit",
    title: "View Edit",
    name: "view_edit",
    value: "viewDetails",
    variant: "base"
    }
}
];
export default class RuleRuleException extends LightningElement {
@api ruleId;
@track ruleExceptions=[];
@track error;
@wire(getRuleExceptions, { ruleId: '$ruleId'})
wiredRuleExceptions({ error, data }) {
    if (data) {
        this.ruleExceptions = data;
        this.error = undefined;        
    } else if (error) {
        this.error = error;
        this.ruleExceptions = undefined;
    }
}
handleRuleExceptionRowAction(event){
alert(event.detail.row);
}


}