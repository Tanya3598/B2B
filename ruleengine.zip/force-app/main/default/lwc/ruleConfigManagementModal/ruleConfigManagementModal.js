import { LightningElement,api } from 'lwc';

export default class RuleConfigManagementModal extends LightningElement {
    @api header;
    @api tagline;
    @api action;
    @api recordId;
    
    connectedCallback() {
        switch (this.action) {
            case 'create':
                this.header = 'New Rule';
                break;            
            case 'edit':
                this.header = 'Edit Rule';
            case 'view':
                    this.header = 'Rule Details';
                break;
            
        }
    }

    get displayRuleForm() {
        return this.action === 'view' || this.action === 'edit' || this.action === 'create' ;
    }

    handleClose() {
        this.dispatchEvent(new CustomEvent('close'));
    }

    handleSave() {           
        this.dispatchEvent(new CustomEvent('save'));
    }
}