import { api, track, LightningElement } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getRuleExceptions from "@salesforce/apex/RuleConfiguratonController.getRuleExceptions";
import getRuleCriterias from "@salesforce/apex/RuleConfiguratonController.getRuleCriterias";
import getRuleActions from "@salesforce/apex/RuleConfiguratonController.getRuleActions";
import getRuleRelatedRecords from "@salesforce/apex/RuleConfiguratonController.getRuleRelatedRecords";
//import getRecordNotifyChange from "lightning/uiRecordApi"
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import jspdf from '@salesforce/resourceUrl/jsPDF';
import jspdf_auto_table from '@salesforce/resourceUrl/jspdfAutotable';
import EPAM_LOGO from '@salesforce/resourceUrl/EPAM_LOGO';

const actions_criteria = [
    { label: 'Edit', name: 'edit_criteria' },
];
const actions_action = [
    { label: 'Edit', name: 'edit_action' },
];
const actions_exception = [
    { label: 'Edit', name: 'edit_exception' },
];

export default class RuleConfigurationRelatedRecords extends LightningElement {

    @api
    relatedRuleExceptions;
    @api
    relatedRuleCriterias;
    @api
    relatedRuleActions;


    _ruleId = 'a003t00000rXw20AAC';
    _ruleName = 'Test1000000000000000000';
    openModal = false;
    modalTitle = '';
    selectedActionRowId;
    ruleReadOnlyFieldVal;
    modalTitle;
    objectApiName;
    editableFiledsFromParent;
    readOnlyFieldsFromParent;
    recordSize = 5;
    isConnectedCallback = false;
    previousLayoutSize = 12;
    previouSmallLayoutSize = 8;
    previousMediumLayoutSize = 4;

    optionsLayoutSize = 12;
    optionsSmallLayoutSize = 8;
    optionsMediumLayoutSize = 4;

    nextLayoutSize = 12;
    nextSmallLayoutSize = 8;
    nextMediumLayoutSize = 4;

    criteriasAvailable = false;
    noCriteriaRecords = false;
    actionsAvailable = false;
    noActionRecords = false;
    exceptionsAvailable = false;
    noExceptionRecords = false;

    criteriaEditableFields = ['Name', 'EPAMRuleEngine__Sequence__c', 'EPAMRuleEngine__Active__c', 'EPAMRuleEngine__Eligibility_Criteria__c'];
    criteriaReadOnlyFields = ['EPAMRuleEngine__Rule__c'];

    actionEditableFields = ['Name', 'EPAMRuleEngine__Active__c', 'EPAMRuleEngine__Field_To_Evaluate__c', 'EPAMRuleEngine__Action__c',
        'EPAMRuleEngine__From_Email_Address__c', 'EPAMRuleEngine__Email_Template_Api_Name__c', 'EPAMRuleEngine__To_Email_Address__c',
        'EPAMRuleEngine__Email_Subject__c', 'EPAMRuleEngine__Reply_To_Email_Address__c', 'EPAMRuleEngine__Email_Body__c',
        'EPAMRuleEngine__CC_Email_Address__c'];
    actionReadOnlyFields = ['EPAMRuleEngine__Rule__c'];

    exceptionEditableFields = ['Name', 'EPAMRuleEngine__Sequence__c', 'EPAMRuleEngine__Active__c',
        'EPAMRuleEngine__Eligibility_Criteria__c', 'EPAMRuleEngine__Exception_Message__c'];
    exceptionReadOnlyFields = ['EPAMRuleEngine__Rule__c'];

    @track finalCriteriaRecords;
    @track paginatorCriteriaRecords;
    @track finalActionRecords;
    @track paginatorActionRecords;
    @track finalExceptionRecords;
    @track paginatorExceptionRecords;
    @track sortBy = 'EPAMRuleEngine__Sequence__c';
    @track sortDirection = 'desc';


    @track
    ruleCriteriacolumns = [
        { label: 'Rule Criteria Name', fieldName: 'Name', type: 'string' },
        { label: 'Active', fieldName: 'EPAMRuleEngine__Active__c', type: 'boolean' },
        {
            label: 'Sequence',
            fieldName: 'EPAMRuleEngine__Sequence__c',
            type: 'number',
            hideDefaultActions: true,
            sortable: true,
            cellAttributes: {
                alignment: 'left'
            },
        },
        { label: 'Eligibility Criteria', fieldName: 'EPAMRuleEngine__Eligibility_Criteria__c', type: 'string' },
        /*{
            type: 'action',
            typeAttributes: { rowActions: actions_criteria }
        }*/
    ];
    @track
    ruleActioncolumns = [
        { label: 'Rule Action Name', fieldName: 'Name', type: 'string' },
        { label: 'Active', fieldName: 'EPAMRuleEngine__Active__c', type: 'boolean' },
        { label: 'Field To Evaluate', fieldName: 'EPAMRuleEngine__Field_To_Evaluate__c', type: 'string' },
        { label: 'Action', fieldName: 'EPAMRuleEngine__Action__c', type: 'string' },
        /*{
            type: 'action',
            typeAttributes: { rowActions: actions_action }
        }*/
    ];

    @track
    ruleExceptioncolumns = [
        { label: 'Rule Exception Name', fieldName: 'Name', type: 'string' },
        { label: 'Active', fieldName: 'EPAMRuleEngine__Active__c', type: 'boolean' },
        {
            label: 'Sequence', fieldName: 'EPAMRuleEngine__Sequence__c', type: 'number',
            hideDefaultActions: true,
            sortable: true,
            cellAttributes: {
                alignment: 'left'
            },
        },
        { label: 'Eligibility Criteria', fieldName: 'EPAMRuleEngine__Eligibility_Criteria__c', type: 'string' },
        /*{
            type: 'action',
            typeAttributes: { rowActions: actions_exception }
        }*/
    ];

    get showRuleExceptions() {
        return this.relatedRuleExceptions ? this.relatedRuleExceptions.length > 0 : false;
    }
    get showRuleCriteria() {
        return this.relatedRuleCriterias ? this.relatedRuleCriterias.length > 0 : false;
    }
    get showRuleActions() {
        return this.relatedRuleActions ? this.relatedRuleActions.length > 0 : false;
    }


    criteriasToExport = [];
    actionsToExport = [];
    exceptionsToExport = [];

    connectedCallback() {
        this._ruleId = 'a003t00000rXw20AAC';
        this.criteriasAvailable = false;
        this.actionsAvailable = false;
        this.exceptionsAvailable = false;
        this.noCriteriaRecords = false;
        this.noActionRecords = false;
        this.noExceptionRecords = false;
        this.fetchRelatedRecords();
        console.log('Connected Callback Called...');
    }

    @api
    get ruleId() {
        return this.uppercaseItemName;
    }


    set ruleId(value) {
        console.log(value);
        //console.log('Name==>'+this._ruleName);
        this._ruleId = 'a003t00000rXw20AAC';
        if (value) {
            this.criteriasAvailable = false;
            this.actionsAvailable = false;
            this.exceptionsAvailable = false;
            this.noCriteriaRecords = false;
            this.noActionRecords = false;
            this.noExceptionRecords = false;
            this.fetchRelatedRecords();
        }
    }

    @api
    get ruleName() {
        return this.uppercaseItemName;
    }

    set ruleName(value) {
        this._ruleName = value;
    }

    fetchRelatedRecords() {
        getRuleRelatedRecords({ ruleId: this._ruleId })
            .then(result => {
                console.log('relatedRecords are ==>', JSON.parse(JSON.stringify(result)));
                this.relatedRuleCriterias = result.lstRuleCriterias;
                let sortedRecords = this.sortData(this.sortBy, this.sortDirection, result.lstRuleCriterias);
                this.paginatorCriteriaRecords = sortedRecords;
                this.criteriasToExport = sortedRecords;
                this.criteriasAvailable = true;
                if (sortedRecords.length === 0) {
                    this.noCriteriaRecords = true;
                }

                this.relatedRuleActions = result.lstRuleAcions;
                let sortedRecords2 = this.sortData(this.sortBy, this.sortDirection, result.lstRuleAcions);
                this.paginatorActionRecords = sortedRecords2;
                this.actionsToExport = sortedRecords2;
                this.actionsAvailable = true;
                if (sortedRecords2.length === 0) {
                    this.noActionRecords = true;
                }

                this.relatedRuleExceptions = result.lstRuleExceptions;
                let sortedRecords3 = this.sortData(this.sortBy, this.sortDirection, result.lstRuleExceptions);
                this.paginatorExceptionRecords = sortedRecords3;
                this.exceptionsToExport = sortedRecords3;
                this.exceptionsAvailable = true;
                if (sortedRecords3.length === 0) {
                    this.noExceptionRecords = true;
                }
            })
            .catch(error => {
                console.error('getRuleRelatedRecords || error || ' + JSON.stringify(error));
            });
    }

    fetchRuleCriterias() {
        getRuleCriterias({ ruleId: this._ruleId })
            .then(result => {
                console.log('fetchRuleCriterias are ==>', JSON.parse(JSON.stringify(result)));
                this.relatedRuleCriterias = result;
                let res = result;
                let sortedRecords = this.sortData(this.sortBy, this.sortDirection, res);
                this.paginatorCriteriaRecords = sortedRecords;
                this.criteriasAvailable = true;
                if (sortedRecords.length === 0) {
                    this.noCriteriaRecords = true;
                }
            })
            .catch(error => {
                console.error('fetchRuleCriterias || error || ' + JSON.stringify(error));
            });
    }

    fetchRuleActions() {
        getRuleActions({ ruleId: this._ruleId })
            .then(result => {
                console.log('fetchRuleActions are ==>', JSON.parse(JSON.stringify(result)));
                this.relatedRuleActions = result;
                let res = result;
                let sortedRecords2 = this.sortData(this.sortBy, this.sortDirection, res);
                this.paginatorActionRecords = sortedRecords2;
                this.actionsAvailable = true;
                if (sortedRecords2.length === 0) {
                    this.noActionRecords = true;
                }
            })
            .catch(error => {
                console.error('fetchRuleActions || error || ' + JSON.stringify(error));
            });
    }

    fetchRuleExceptions() {
        getRuleExceptions({ ruleId: this._ruleId })
            .then(result => {
                console.log('fetchRuleExceptions are ==>', JSON.parse(JSON.stringify(result)));
                this.relatedRuleExceptions = result;
                let res = result;
                let sortedRecords3 = this.sortData(this.sortBy, this.sortDirection, res);
                this.paginatorExceptionRecords = sortedRecords3;
                this.exceptionsAvailable = true;
                if (sortedRecords3.length === 0) {
                    this.noExceptionRecords = true;
                }
            })
            .catch(error => {
                console.error('fetchRuleExceptions || error || ' + JSON.stringify(error));
            });
    }

    handleNew(event) {
        //console.log( 'clickedButton==>',event.target.name);
        switch (event.target.name) {
            case "NewCriteria": {
                this.modalTitle = 'New Criteria';
                this.selectedActionRowId = undefined;
                this.ruleReadOnlyFieldVal = { 'EPAMRuleEngine__Rule__c': this._ruleId };
                this.objectApiName = 'EPAMRuleEngine__Rule_Criteria__c';
                this.editableFiledsFromParent = this.criteriaEditableFields;
                this.readOnlyFieldsFromParent = this.criteriaReadOnlyFields;
                this.openModal = true;
                //console.log('Inside NewCriteria ');
                break;
            }
            case "NewAction": {
                this.objectApiName = 'EPAMRuleEngine__Rule_Action__c';
                this.selectedActionRowId = undefined;
                this.ruleReadOnlyFieldVal = { 'EPAMRuleEngine__Rule__c': this._ruleId };
                this.editableFiledsFromParent = this.actionEditableFields;
                this.readOnlyFieldsFromParent = this.actionReadOnlyFields;
                this.openModal = true;
                //console.log('Inside NewAction ');
                break;
            }
            case "NewException": {
                this.objectApiName = 'EPAMRuleEngine__Rule_Exception__c';
                this.selectedActionRowId = undefined;
                this.ruleReadOnlyFieldVal = { 'EPAMRuleEngine__Rule__c': this._ruleId };
                this.editableFiledsFromParent = this.exceptionEditableFields;
                this.readOnlyFieldsFromParent = this.exceptionReadOnlyFields;
                this.openModal = true;
                //console.log('Inside NewException ');
                break;
            }

        }
    }

    handleEdit(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;

        switch (actionName) {
            case "edit_criteria": {
                this.modalTitle = 'Edit Criteria';
                this.selectedActionRowId = row.Id;
                this.ruleReadOnlyFieldVal = { 'EPAMRuleEngine__Rule__c': this._ruleId };
                this.objectApiName = 'EPAMRuleEngine__Rule_Criteria__c';
                this.editableFiledsFromParent = this.criteriaEditableFields;
                this.readOnlyFieldsFromParent = this.criteriaReadOnlyFields;
                this.openModal = true;

                break;
            }
            case "edit_action": {
                this.objectApiName = 'EPAMRuleEngine__Rule_Action__c';
                this.selectedActionRowId = row.Id;
                this.ruleReadOnlyFieldVal = { 'EPAMRuleEngine__Rule__c': this._ruleId };
                this.editableFiledsFromParent = this.actionEditableFields;
                this.readOnlyFieldsFromParent = this.actionReadOnlyFields;
                this.openModal = true;
                break;
            }
            case "edit_exception": {
                this.objectApiName = 'EPAMRuleEngine__Rule_Exception__c';
                this.selectedActionRowId = row.Id;
                this.ruleReadOnlyFieldVal = { 'EPAMRuleEngine__Rule__c': this._ruleId };
                this.editableFiledsFromParent = this.exceptionEditableFields;
                this.readOnlyFieldsFromParent = this.exceptionReadOnlyFields;
                this.openModal = true;
                break;
            }
        }

    }

    toggleRoleModal() {
        //this.actionEditRecord=undefined;
        this.openModal = false;
        this.modalTitle = '';
        this.selectedActionRowId = '';
        this.ruleReadOnlyFieldVal = undefined;
        this.objectApiName = '';
        this.editableFiledsFromParent = undefined;
        this.readOnlyFieldsFromParent = undefined;
    }

    handleRuleCreateEditSuccess(event) {
        //console.log('success handled==>',this.objectApiName);
        this.dispatchEvent(
            new ShowToastEvent({
                title: "Success!!",
                message: "Record saved successfully!!",
                variant: "success"
            })
        );
        this.criteriasAvailable = false;
        this.actionsAvailable = false;
        this.exceptionsAvailable = false;
        this.noCriteriaRecords = false;
        this.noActionRecords = false;
        this.noExceptionRecords = false;


        console.log('obj name==>', this.objectApiName);
        switch (this.objectApiName) {
            case 'EPAMRuleEngine__Rule_Criteria__c': {
                this.fetchRuleCriterias();
                this.actionsAvailable = true;
                this.exceptionsAvailable = true;
                if (this.relatedRuleActions.length === 0) {
                    this.noActionRecords = true;
                }
                if (this.relatedRuleExceptions.length === 0) {
                    this.noExceptionRecords = true;
                }
                break;
            }
            case 'EPAMRuleEngine__Rule_Action__c': {

                this.fetchRuleActions();
                this.criteriasAvailable = true;
                this.exceptionsAvailable = true;
                if (this.relatedRuleCriterias.length === 0) {
                    this.noCriteriaRecords = true;
                }
                if (this.relatedRuleExceptions.length === 0) {
                    this.noExceptionRecords = true;
                }
                break;
            }
            case 'EPAMRuleEngine__Rule_Exception__c': {

                this.fetchRuleExceptions();
                this.criteriasAvailable = true;
                this.actionsAvailable = true;
                if (this.relatedRuleCriterias.length === 0) {
                    this.noCriteriaRecords = true;
                }
                if (this.relatedRuleActions.length === 0) {
                    this.noActionRecords = true;
                }
                break;
            }
        }
        this.toggleRoleModal();

    }

    updateHandler1(event) {
        console.log('response after pagination', JSON.parse(JSON.stringify(event.detail.records)));
        this.finalCriteriaRecords = event.detail.records;

    }
    updateHandler2(event) {
        console.log(JSON.parse(JSON.stringify(event.detail.records)));
        this.finalActionRecords = event.detail.records;
    }
    updateHandler3(event) {
        console.log(JSON.parse(JSON.stringify(event.detail.records)));
        this.finalExceptionRecords = event.detail.records;
    }

    doColumnSorting(event) {
        let fieldName = event.detail.fieldName;
        let sortDirection = event.detail.sortDirection;
        this.sortBy = fieldName;
        this.sortDirection = sortDirection;
        console.log(`sortBy ==> ${fieldName} sortDir==>sortDirection`);
        //this.sortData(fieldName, sortDirection);
        this.paginatorCriteriaRecords = this.sortData(fieldName, sortDirection, this.paginatorCriteriaRecords);
    }

    doColumnSorting2(event) {
        let fieldName = event.detail.fieldName;
        let sortDirection = event.detail.sortDirection;
        this.sortBy = fieldName;
        this.sortDirection = sortDirection;
        //this.sortData(fieldName, sortDirection);
        this.paginatorExceptionRecords = this.sortData(fieldName, sortDirection, this.paginatorExceptionRecords);
    }

    sortData(fieldName, sortDirection, records) {
        let parseData = JSON.parse(JSON.stringify(records));
        // Return the value stored in the field
        let keyValue = (a) => {
            return a[fieldName];
        };
        // cheking reverse direction
        let isReverse = sortDirection === 'asc' ? 1 : -1;
        // sorting data
        parseData.sort((x, y) => {
            x = keyValue(x) ? keyValue(x) : ''; // handling null values
            y = keyValue(y) ? keyValue(y) : '';
            // sorting values based on direction
            return isReverse * ((x > y) - (y > x));
        });
        return parseData;
    }

    //PDF Generation Logic
    calculatedHeight = 0;
    renderedCallback() {
        // Promise.all([
        //     loadScript(this, jspdf)
        // ]);
        Promise.all([loadScript(this, jspdf), loadScript(this, jspdf_auto_table)])
            .then(() => {
                console.log('loaded');
                this.jsPDFLoaded = true;
            })
            .catch(() => {
                console.log('not loaded');
            });
    }

    headers = this.createHeaders([
        //"Rule Criteria Name",
        "Id",
        "Name",
        "OwnerId",
        "IsDeleted"
        // "Active",
        // "Sequence",
        // "Eligibility Criteria"
        // "EPAMRuleEngine__Sequence__c",
        // "EPAMRuleEngine__Eligibility_Criteria__c"
    ]);

    headers1 = this.createHeaders([
        "Rule Criteria Name",
        "Active",
        "Sequence",
        "Eligibility Criteria"
    ]);

    headers2 = this.createHeaders([
        "Rule Action Name",
        "Active",
        "Field To Evaluate",
        "Action"
    ]);

    headers3 = this.createHeaders([
        "Rule Exception Name",
        "Active",
        "Sequence",
        "Eligibility Criteria"
    ]);

    createHeaders(keys) {
        var result = [];
        for (var i = 0; i < keys.length; i += 1) {
            let widthVal = 50;
            /*if(keys[i] === 'IsDeleted' || keys[i] === 'Name'){
              widthVal = 50;
            }
  
            if(keys[i] === 'Rule Criteria Name' || keys[i] === 'Eligibility Criteria'){
              widthVal = 45;
            }*/
            result.push({
                id: keys[i],
                name: keys[i],
                prompt: keys[i],
                width: widthVal,
                align: "center",
                padding: 0
            });
        }
        return result;
    }

    generatePdf() {
        try {

            // console.log('Generate Pdf called');
            // console.log(JSON.stringify(this.finalCriteriaRecords));
            let recordsToExport = [];
            let recordsToExport1 = [];
            let recordsToExport2 = [];
            // console.log(JSON.stringify(this.criteriasToExport));
            for (var i = 0; i <= this.criteriasToExport.length - 1; i++) {
                // var obj = {
                //     "Rule Criteria Name": this.criteriasToExport[i].Name,
                //     "Active": this.criteriasToExport[i].EPAMRuleEngine__Active__c.toString(),
                //     "Sequence": this.criteriasToExport[i].EPAMRuleEngine__Sequence__c.toString(),
                //     "Eligibility Criteria": this.criteriasToExport[i].EPAMRuleEngine__Eligibility_Criteria__c
                // }
                var obj = [
                    this.criteriasToExport[i].Name,
                    this.criteriasToExport[i].EPAMRuleEngine__Active__c.toString(),
                    this.criteriasToExport[i].EPAMRuleEngine__Sequence__c.toString(),
                    this.criteriasToExport[i].EPAMRuleEngine__Eligibility_Criteria__c
                ]
                recordsToExport.push(obj);
            }

            for (var i = 0; i <= this.actionsToExport.length - 1; i++) {
                // var obj1 = {
                //     "Rule Action Name": this.actionsToExport[i].Name,
                //     "Active": this.actionsToExport[i].EPAMRuleEngine__Active__c.toString(),
                //     "Field To Evaluate": this.actionsToExport[i].EPAMRuleEngine__Field_To_Evaluate__c.toString(),
                //     "Action": this.actionsToExport[i].EPAMRuleEngine__Action__c
                // }
                var obj1 = [
                    this.actionsToExport[i].Name,
                    this.actionsToExport[i].EPAMRuleEngine__Active__c.toString(),
                    this.actionsToExport[i].EPAMRuleEngine__Field_To_Evaluate__c.toString(),
                    this.actionsToExport[i].EPAMRuleEngine__Action__c
                ]
                recordsToExport1.push(obj1);
            }

            alert(recordsToExport1);
            for (var i = 0; i <= this.exceptionsToExport.length - 1; i++) {
                // var obj2 = {
                //     "Rule Exception Name": this.exceptionsToExport[i].Name,
                //     "Active": this.exceptionsToExport[i].EPAMRuleEngine__Active__c.toString(),
                //     "Sequence": this.exceptionsToExport[i].EPAMRuleEngine__Sequence__c.toString(),
                //     "Eligibility Criteria": this.exceptionsToExport[i].EPAMRuleEngine__Eligibility_Criteria__c.toString()
                // }
                var obj2 = [
                    this.exceptionsToExport[i].Name,
                    this.exceptionsToExport[i].EPAMRuleEngine__Active__c.toString(),
                    this.exceptionsToExport[i].EPAMRuleEngine__Sequence__c.toString(),
                    this.exceptionsToExport[i].EPAMRuleEngine__Eligibility_Criteria__c.toString()
                ]
                recordsToExport2.push(obj2);
            }

            // console.log(JSON.stringify(recordsToExport));
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF({
                orientation: 'p',
                unit: 'mm',
                format: 'a4',
                putOnlyUsedFonts: true,
                encryption: {
                    //userPassword: "user",
                    //ownerPassword: "owner",
                    userPermissions: ["print", "modify", "copy", "annot-forms"]
                    // try changing the user permissions granted
                }
            });

            //doc.text("Export Sheet", 20, 20);
            //doc.table(30,30, [], [],{ autosize: true });

            doc.text('Rule Name:  ' + this._ruleName, 15, 20);
            doc.table(30, 30, [], [], { autosize: true });

                doc.text("Rule Criterias : ", 15, 30);
                // doc.table(30, 40, recordsToExport, this.headers1, { autosize: true });
                doc.autoTable({
                    startY: 35,
                    head: [[
                        "Rule Criteria Name",
                        "Active",
                        "Sequence",
                        "Eligibility Criteria"
                    ]],
                    body: recordsToExport
                    ,
                });

                //
                doc.addPage();

            //  console.log('Calculated Height : ' + recordsToExport.length * 15);
            // this.calculatedHeight = 50 + (recordsToExport.length * 15);
            // console.log('Table 2 text starts here ...' + this.calculatedHeight);
            // doc.text("Rule Actions", 20, this.calculatedHeight);
            // this.calculatedHeight = this.calculatedHeight + 10;
            // doc.table(30, this.calculatedHeight, recordsToExport1, this.headers2, { autosize: true });
                doc.text("Rule Actions : ", 15, 20);
                doc.autoTable({
                    theme: 'grid',
                    startY: 25,
                    head: [[
                        "Rule Action Name",
                        "Active",
                        "Field To Evaluate",
                        "Action"
                    ]],
                    body: recordsToExport1,
                });

                //
                doc.addPage();
            
            // console.log('Calculated Height : ' + recordsToExport1.length * 15);
            // this.calculatedHeight = 140 + (recordsToExport1.length * 15);
            // console.log('Table 3 text starts here ...' + this.calculatedHeight);
            // doc.text("Rule Exceptions", 20, this.calculatedHeight);
            // this.calculatedHeight = this.calculatedHeight + 10;
            // doc.table(30, this.calculatedHeight, recordsToExport2, this.headers3, { autosize: true });
                doc.text("Rule Exceptions : ", 15, 20);
                doc.autoTable({
                    startY: 25,
                    head: [[
                        "Rule Exception Name",
                        "Active",
                        "Sequence",
                        "Eligibility Criteria"
                    ]],
                    body: recordsToExport2,
                });
            
            // console.log('Internal Page Width: ' + doc.internal.pageSize.width);
            // console.log('Internal Page Height: ' + doc.internal.pageSize.height);
            // console.log('Printing...' + JSON.stringify(doc.internal));

            var pageCount = doc.internal.getNumberOfPages(); //Total Page Number
            console.log('TOTAL PAGES: ' + pageCount);
            for (i = 0; i < pageCount; i++) {
                doc.setPage(i);
                let pageCurrent = doc.internal.getCurrentPageInfo().pageNumber; //Current Page
                var img = new Image();
                img.src = EPAM_LOGO;
                doc.addImage(img, 'png', 10, 287, 20, 5);
                doc.setFontSize(9);
                doc.setTextColor(150, 0, 0);
                doc.setFont("times");
                doc.text('page: ' + pageCurrent + '/' + pageCount, 95, 290);
                doc.rect(10, 8, doc.internal.pageSize.width - 20, doc.internal.pageSize.height - 20, 'S');
            }

            doc.save();

        } catch (e) {
            console.log('Exception occurred...');
            console.log(e);
        }
    }



    generateData() {
        //console.log('Data Length: ' + this.finalCriteriaRecords.length);

        //if (this.finalCriteriaRecords.length > 0 || this.finalActionRecords.length>0 || this.finalExceptionRecords.length>0) {
        if (this.finalCriteriaRecords.length > 0) {
            alert(this.finalExceptionRecords.length);
            this.generatePdf("demo.pdf");
        }

    }
}